-dontobfuscate

-ignorewarnings
-dontwarn
