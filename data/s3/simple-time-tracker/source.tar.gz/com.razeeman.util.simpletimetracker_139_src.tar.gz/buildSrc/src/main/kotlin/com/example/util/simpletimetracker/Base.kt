package com.example.util.simpletimetracker

object Base {
    const val applicationId = "com.razeeman.util.simpletimetracker"
    const val namespace = "com.example.util.simpletimetracker"

    // Raise by 2 to account for wear version code.
    const val versionCode = 139
    const val versionName = "1.57"
    const val minSDK = 21
    const val currentSDK = 35

    const val versionCodeWear = versionCode + 1
    const val versionNameWear = versionName + "w"
    const val minSDKWear = 26
    const val currentSDKWear = currentSDK
    const val targetSDKWear = 34

    // Raise after wear api changes.
    const val wearApiVersion = 7
}
